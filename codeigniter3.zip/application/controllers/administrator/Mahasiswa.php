<?php
defined('BASEPATH') or exit('Not Allowed Direct Access');

class Mahasiswa extends CI_Controller {

    public function __construct() {
        parent:: __construct();
        $this->load->model('mahasiswa_model');
    }
    public function index() {
        $this->data['title'] = 'Daftar Mahasiswa';
        $this->data['mahasiswa'] = $this->mahasiswa_model->getData();
        $this->template->load('mahasiswa/list-mahasiswa', $this->data);
    }

    public function add() {
        $this->data['title'] = 'Tambah Data';
        $this->template->load('mahasiswa/add', $this->data);
    }

    public function add_save() {
        $data =array(
            'nama_mahasiswa' => $this->input->post('nama_mahasiswa'),
            'kota_asal' => $this->input->post('kota_asal'),
            'tanggal_lahir' => $this->input->post('tanggal_lahir'),
        );

        $simpan = $this->db->insert('mahasiswa',$data);

        if($simpan) {
            redirect('administrator/mahasiswa');
        }else {
            echo('data tidak dapat dimasukan');
        }
        
    }

    public function edit($id) {
        $this->data['title'] = 'Edit Data';
        $this->data['mahasiswa'] = $this->mahasiswa_model->edit($id);
        $this->template->load('mahasiswa/edit', $this->data);
    }

    public function edit_save() {
        $data =array(
            'nama_mahasiswa' => $this->input->post('nama_mahasiswa'),
            'kota_asal' => $this->input->post('kota_asal'),
            'tanggal_lahir' => $this->input->post('tanggal_lahir'),
        );

        $update = $this->mahasiswa_model->edit_save($data, $this->input->post('id'));
        if($update) {
            redirect('administrator/mahasiswa');
        }else{
            echo('gagal update data');
        }
    }

    public function hapus($id) {
        $delete = $this->mahasiswa_model->delete($id);

        if($delete) {
            redirect('administrator/mahasiswa');
        }else {
            echo('data gabisa dihapus');
        }
    }
}

?>