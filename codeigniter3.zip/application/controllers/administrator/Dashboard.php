<?php
defined('BASEPATH') OR exit('No direct script access allowed');
    class Dashboard extends CI_Controller {
        public function index() {
            // $this->load->view('partial/layout');
            
            $this->data['title'] = 'Dashboard';
            $this->template->load('dashboard', $this->data);
        }   
        public function profile() {
            // $this->load->view('partial/layout');
            $this->data['title'] = 'Profile';
            $this->template->load('sidebar/profile', $this->data);
        }   
        public function login() {
            // $this->load->view('partial/layout');
            $this->data['title'] = 'Login';
            $this->template->load('sidebar/login', $this->data);
        }   
    }
?>