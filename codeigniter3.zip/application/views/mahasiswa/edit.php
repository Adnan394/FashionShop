<div class="card">
    <div class="card-body">
        <h5 class="card-title">Edit Data Mahasiswa</h5>

        <!-- Horizontal Form -->
        <?= form_open(base_url('index.php/administrator/mahasiswa/edit_save')) ?>
        <div class="row mb-3">
            <input type="hidden" name="id" value="<?=$mahasiswa->id?>">
            <label for="inputEmail3" class="col-sm-2 col-form-label">Nama</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="inputText" name="nama_mahasiswa"
                    value="<?= $mahasiswa->nama_mahasiswa?>">
            </div>
        </div>
        <div class="row mb-3">
            <label for="inputext3" class="col-sm-2 col-form-label">Kota Asal</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="inputkota" name="kota_asal"
                    value="<?= $mahasiswa->kota_asal?>">
            </div>
        </div>
        <div class="row mb-3">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Tanggal Lahir</label>
            <div class="col-sm-10">
                <input type="date" class="form-control" id="inputDate" name="tanggal_lahir"
                    value="<?= $mahasiswa->tanggal_lahir?>">
            </div>
        </div>
        <div class="">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
        <?= form_close() ?>
    </div>
</div>